package block

import (
	"bytes"
	"encoding/binary"

	"github.com/Univ-Wyo-Education/Blockchain-4010-Fall-2018/Assignments/A-02/hash"
)

const GenesisDesc = "GenesisBlock Fri Aug 17 23:16:12 MDT 2018"

type BlockType struct {
	Index         int
	Desc          string // if "genesis" string then this is a genesis block.
	ThisBlockHash hash.BlockHashType
	PrevBlockHash hash.BlockHashType // is 0 if this is a genesis block
	Seal          hash.SealType
	// Add Transactions to Block Later
}

// InitGenesisBlock create and return a genesis block.   This is a special
// block at the beginning of a chain.
func InitGenesisBlock() (gb *BlockType) {
	gb = &BlockType{
		Index:         0,
		Desc:          GenesisDesc,
		ThisBlockHash: []byte{},
		PrevBlockHash: []byte{},
		Seal:          []byte{},
	}
	gb.ThisBlockHash = HashOf(HashSearalizeBlock(gb))
	return
}

// InitBlock creates and returns a block.
func InitBlock(ii int, dd string, prev hash.BlockHashType) (bk *BlockType) {
	bk = &BlockType{
		Index:         ii,
		Desc:          dd,
		ThisBlockHash: []byte{},
		PrevBlockHash: prev,
		Seal:          []byte{},
	}
	bk.ThisBlockHash = HashOf(HashSearalizeBlock(bk))
	return
}

// IsGenesisBlock returns true if this is a genisis block.
func IsGenesisBlock(bk *BlockType) bool {
	if bk.Desc == GenesisDesc && len(bk.PrevBlockHash) == 0 {
		return true
	}
	return false
}

// HashOfBlock calcualtes the hash of the 'data' and returns it.
func HashOf(data []byte) (h []byte) {
	h = hash.Keccak256(data)
	return
}

// HashSearalizeBlock searializes into bytes the fields that will be hashed.
func HashSearalizeBlock(bk *BlockType) []byte {
	var buf bytes.Buffer

	binary.Write(&buf, binary.BigEndian, bk.Index)

	buf.Write([]byte(bk.Desc))

	// Additional fields will need to be added at this point.

	return buf.Bytes()
}

// HashSearalizeBlock searializes into bytes the fields that will be hashed.
func HashSearalizeForSeal(bk *BlockType) []byte {
	var buf bytes.Buffer

	binary.Write(&buf, binary.BigEndian, bk.Index)

	buf.Write([]byte(bk.Desc))

	buf.Write([]byte(bk.ThisBlockHash))

	buf.Write([]byte(bk.PrevBlockHash))

	// Additional fields will need to be added at this point.

	return buf.Bytes()
}

package genesis

import (
	"fmt"
	"os"

	"github.com/Univ-Wyo-Education/Blockchain-4010-Fall-2018/Assignments/A-02/cli"
)

type CLI struct {
}

func main() {

	// Commands
	//		create-genesis
	//		test-read-block
	//		test-write-write

	fmt.Println("vim-go")
	cli = cli.NewCLI()

	if len(os.Args) < 2 {
		cli.Usage()
		os.Exit(1)
	}

	switch os.Args[1] {
	case "create-genisis":
		cli.CreateGenesis(os.Args[2:])
	case "test-read-block":
		cli.TestReadBlock(os.Args[2:])
	case "test-write-block":
		cli.TestWriteBlock(os.Args[2:])
	default:
		cli.Usage()
		os.Exit(1)
	}
}

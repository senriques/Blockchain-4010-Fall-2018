Genisis Block and the beginning of our blockchain
=============================================================

At the root of our blockchain is a special block called a "genesis" block.  
Basically the "genesis" block is the beginning block in our block chain.  It is
special because it will not point back to any previous block.

Our goal is to write

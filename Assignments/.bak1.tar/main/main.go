package main

import (
	"os"

	"github.com/Univ-Wyo-Education/Blockchain-4010-Fall-2018/Assignments/A-02/cli"
)

func main() {
	// Commands
	//		create-genesis
	//		test-read-block
	//		test-write-write

	cc := cli.NewCLI()

	if len(os.Args) < 2 {
		cc.Usage()
		os.Exit(1)
	}

	switch os.Args[1] {
	case "create-genesis":
		cc.CreateGenesis(os.Args[2:])
	case "test-read-block":
		cc.TestReadBlock(os.Args[2:])
	case "test-write-block":
		cc.TestWriteBlock(os.Args[2:])
	default:
		cc.Usage()
		os.Exit(1)
	}
}
